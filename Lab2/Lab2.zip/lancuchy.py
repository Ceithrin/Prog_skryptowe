#-*-coding: utf-8-*-
lancuch1 = '''Tekst w języku polskim
Łańcuch
Kołątaj'''
lancuch2 = '''Drugi tekst w języku polskim
Kołobrzeg
Pięta'''
print((lancuch1+'\n'+lancuch2+'\n')*3, end='')
lancuch = "RosesAreRed"
print(lancuch[0])
print(lancuch[0:2])
print(lancuch[2:])
print(lancuch[-2])
print(lancuch[-3:])
print(lancuch[1::2])

# lancuch[0] = "x"
# print(lancuch)